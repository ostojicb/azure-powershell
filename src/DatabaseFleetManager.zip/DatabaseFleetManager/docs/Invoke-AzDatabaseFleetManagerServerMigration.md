---
external help file:
Module Name: Az.DatabaseFleetManager
online version: https://learn.microsoft.com/powershell/module/az.databasefleetmanager/invoke-azdatabasefleetmanagerservermigration
schema: 2.0.0
---

# Invoke-AzDatabaseFleetManagerServerMigration

## SYNOPSIS
Migrates existing logical server into fleet.

## SYNTAX

### ServerExpanded (Default)
```
Invoke-AzDatabaseFleetManagerServerMigration -FleetName <String> -FleetspaceName <String>
 -ResourceGroupName <String> [-SubscriptionId <String>] [-DestinationTierOverride <Hashtable>]
 [-SourceResourceGroupName <String>] [-SourceServerName <String>] [-SourceSubscriptionId <String>]
 [-TierName <String>] [-DefaultProfile <PSObject>] [-AsJob] [-NoWait] [-Confirm] [-WhatIf]
 [<CommonParameters>]
```

### Server
```
Invoke-AzDatabaseFleetManagerServerMigration -FleetName <String> -FleetspaceName <String>
 -ResourceGroupName <String> -Parameter <IMigrateServerDefinition> [-SubscriptionId <String>]
 [-DefaultProfile <PSObject>] [-AsJob] [-NoWait] [-Confirm] [-WhatIf] [<CommonParameters>]
```

### ServerViaIdentity
```
Invoke-AzDatabaseFleetManagerServerMigration -InputObject <IDatabaseFleetManagerIdentity>
 -Parameter <IMigrateServerDefinition> [-DefaultProfile <PSObject>] [-AsJob] [-NoWait] [-Confirm] [-WhatIf]
 [<CommonParameters>]
```

### ServerViaIdentityExpanded
```
Invoke-AzDatabaseFleetManagerServerMigration -InputObject <IDatabaseFleetManagerIdentity>
 [-DestinationTierOverride <Hashtable>] [-SourceResourceGroupName <String>] [-SourceServerName <String>]
 [-SourceSubscriptionId <String>] [-TierName <String>] [-DefaultProfile <PSObject>] [-AsJob] [-NoWait]
 [-Confirm] [-WhatIf] [<CommonParameters>]
```

### ServerViaIdentityFleet
```
Invoke-AzDatabaseFleetManagerServerMigration -FleetInputObject <IDatabaseFleetManagerIdentity>
 -FleetspaceName <String> -Parameter <IMigrateServerDefinition> [-DefaultProfile <PSObject>] [-AsJob]
 [-NoWait] [-Confirm] [-WhatIf] [<CommonParameters>]
```

### ServerViaIdentityFleetExpanded
```
Invoke-AzDatabaseFleetManagerServerMigration -FleetInputObject <IDatabaseFleetManagerIdentity>
 -FleetspaceName <String> [-DestinationTierOverride <Hashtable>] [-SourceResourceGroupName <String>]
 [-SourceServerName <String>] [-SourceSubscriptionId <String>] [-TierName <String>]
 [-DefaultProfile <PSObject>] [-AsJob] [-NoWait] [-Confirm] [-WhatIf] [<CommonParameters>]
```

### ServerViaJsonFilePath
```
Invoke-AzDatabaseFleetManagerServerMigration -FleetName <String> -FleetspaceName <String>
 -ResourceGroupName <String> -JsonFilePath <String> [-SubscriptionId <String>] [-DefaultProfile <PSObject>]
 [-AsJob] [-NoWait] [-Confirm] [-WhatIf] [<CommonParameters>]
```

### ServerViaJsonString
```
Invoke-AzDatabaseFleetManagerServerMigration -FleetName <String> -FleetspaceName <String>
 -ResourceGroupName <String> -JsonString <String> [-SubscriptionId <String>] [-DefaultProfile <PSObject>]
 [-AsJob] [-NoWait] [-Confirm] [-WhatIf] [<CommonParameters>]
```

## DESCRIPTION
Migrates existing logical server into fleet.

## EXAMPLES

### Example 1: {{ Add title here }}
```powershell
{{ Add code here }}
```

```output
{{ Add output here }}
```

{{ Add description here }}

### Example 2: {{ Add title here }}
```powershell
{{ Add code here }}
```

```output
{{ Add output here }}
```

{{ Add description here }}

## PARAMETERS

### -AsJob
Run the command as a job

```yaml
Type: System.Management.Automation.SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DefaultProfile
The DefaultProfile parameter is not functional.
Use the SubscriptionId parameter when available if executing the cmdlet against a different subscription.

```yaml
Type: System.Management.Automation.PSObject
Parameter Sets: (All)
Aliases: AzureRMContext, AzureCredential

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DestinationTierOverride
Dictionary of \<string\>

```yaml
Type: System.Collections.Hashtable
Parameter Sets: ServerExpanded, ServerViaIdentityExpanded, ServerViaIdentityFleetExpanded
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -FleetInputObject
Identity Parameter
To construct, see NOTES section for FLEETINPUTOBJECT properties and create a hash table.

```yaml
Type: Microsoft.Azure.PowerShell.Cmdlets.DatabaseFleetManager.Models.IDatabaseFleetManagerIdentity
Parameter Sets: ServerViaIdentityFleet, ServerViaIdentityFleetExpanded
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -FleetName
Name of the database fleet.

```yaml
Type: System.String
Parameter Sets: Server, ServerExpanded, ServerViaJsonFilePath, ServerViaJsonString
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -FleetspaceName
Name of the fleetspace.

```yaml
Type: System.String
Parameter Sets: Server, ServerExpanded, ServerViaIdentityFleet, ServerViaIdentityFleetExpanded, ServerViaJsonFilePath, ServerViaJsonString
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -InputObject
Identity Parameter
To construct, see NOTES section for INPUTOBJECT properties and create a hash table.

```yaml
Type: Microsoft.Azure.PowerShell.Cmdlets.DatabaseFleetManager.Models.IDatabaseFleetManagerIdentity
Parameter Sets: ServerViaIdentity, ServerViaIdentityExpanded
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -JsonFilePath
Path of Json file supplied to the Server operation

```yaml
Type: System.String
Parameter Sets: ServerViaJsonFilePath
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -JsonString
Json string supplied to the Server operation

```yaml
Type: System.String
Parameter Sets: ServerViaJsonString
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -NoWait
Run the command asynchronously

```yaml
Type: System.Management.Automation.SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Parameter
.
To construct, see NOTES section for PARAMETER properties and create a hash table.

```yaml
Type: Microsoft.Azure.PowerShell.Cmdlets.DatabaseFleetManager.Models.IMigrateServerDefinition
Parameter Sets: Server, ServerViaIdentity, ServerViaIdentityFleet
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -ResourceGroupName
Name of the resource group that contains the resource.
You can obtain this value from the Azure Resource Manager API or the portal.

```yaml
Type: System.String
Parameter Sets: Server, ServerExpanded, ServerViaJsonFilePath, ServerViaJsonString
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SourceResourceGroupName
.

```yaml
Type: System.String
Parameter Sets: ServerExpanded, ServerViaIdentityExpanded, ServerViaIdentityFleetExpanded
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SourceServerName
.

```yaml
Type: System.String
Parameter Sets: ServerExpanded, ServerViaIdentityExpanded, ServerViaIdentityFleetExpanded
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SourceSubscriptionId
.

```yaml
Type: System.String
Parameter Sets: ServerExpanded, ServerViaIdentityExpanded, ServerViaIdentityFleetExpanded
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SubscriptionId
Subscription ID that identifies an Azure subscription.

```yaml
Type: System.String
Parameter Sets: Server, ServerExpanded, ServerViaJsonFilePath, ServerViaJsonString
Aliases:

Required: False
Position: Named
Default value: (Get-AzContext).Subscription.Id
Accept pipeline input: False
Accept wildcard characters: False
```

### -TierName
.

```yaml
Type: System.String
Parameter Sets: ServerExpanded, ServerViaIdentityExpanded, ServerViaIdentityFleetExpanded
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: System.Management.Automation.SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: System.Management.Automation.SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### Microsoft.Azure.PowerShell.Cmdlets.DatabaseFleetManager.Models.IDatabaseFleetManagerIdentity

### Microsoft.Azure.PowerShell.Cmdlets.DatabaseFleetManager.Models.IMigrateServerDefinition

## OUTPUTS

### System.Boolean

## NOTES

## RELATED LINKS

